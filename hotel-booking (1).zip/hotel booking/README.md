# hotel-booking 
**Online Hotel Booking &amp; Management System**

**User Role**

- User can view Room facilities, price and availability of the room
- They can book their desire room from online.

**Admin Role**

- Secure Login System for Admin Panel
- Add, Delete, Edit Room Facilities
- Add, Delete, Edit Room Category
- ADD, Remove, Edit Number of Rooms
- View Booked Room
- Add new Admin
